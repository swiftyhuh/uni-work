import java.util.*;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Seminar7 {
    static void main() {
        List<String> words = List.of("hi", "hello", "bye", "goodbye", "java", "stream",
                "lambda", "map", "filter", "reduce", "eye", "queue", "collect", "Hello");
        record Student(String name, int group, double grade) {}
        List<Student> students = List.of(
                new Student("Ana", 921, 9.5), new Student("Bogdan", 922, 4.0),
                new Student("Carmen", 921, 7.0), new Student("Dan", 923, 8.5),
                new Student("Elena", 922, 10.0), new Student("Florin", 923, 5.0),
                new Student("Gabriela", 921, 3.5), new Student("Horia", 922, 6.5));
        String text = "The stream API is lazy. A stream is not a collection: "
                + "the stream is consumed once, and the collection is not.";

//        P1 Loop over the words and print each one on a separate line, with two spaces in front of each word. Do
//        not use map.
        words.stream()
                .forEach(w -> System.out.println("  " + w));

//        P2. Repeat P1, but without the two spaces in front. This is trivial with the approach of P1, so the point here
//        is to use a method reference instead of an explicit lambda.
        words.stream()
                .forEach(System.out::println);

//        P3. Assume that we have a method StringUtils.transformedList(List<String>,
//                Function1<String>) and that we produced transformed lists like this:
//        P3 – the old style
//        interface Function1<T> { T app(T t); }
//        List<String> excitingWords =
//                StringUtils.transformedList(words, s -> s + "!");
//        List<String> eyeWords =
//                StringUtils.transformedList(words, s -> s.replace("i", "eye"));
//        List<String> upperCaseWords =
//                StringUtils.transformedList(words, String::toUpperCase);
//        Produce the same lists with streams and the built-in map. Which interface of java.util.function replaces
//        Function1?

        // java.util.function

        List<String> excitingWords = words.stream()
                .map(s -> s + "!")
                .toList();

        List<String> eyeWords = words.stream()
                .map(s -> s.replace("i", "eye"))
                .collect(Collectors.toList());

        List<String> upperCaseWords = words.stream()
                .map( String::toUpperCase)
                .toList();


//        P4. Assume a method StringUtils.allMatches(List<String>, Predicate1<String>), with
//        interface Predicate1<T> { boolean check(T t); }, and the filtered lists:
//        P4 – the old style
//        List<String> shortWords = StringUtils.allMatches(words, s -> s.length() < 4);
//        List<String> wordsWithB = StringUtils.allMatches(words, s -> s.contains("b"));
//        List<String> evenLengthWords = StringUtils.allMatches(words, s -> s.length() % 2 == 0);
//        Produce the same lists with filter.

        List<String> shortWords = words.stream()
                .filter(s -> s.length() < 4)
                .toList();
        List<String> wordsWithB = words.stream()
                .filter(s -> s.contains("b"))
                .toList();
        List<String> evenLengthWords = words.stream()
                .filter(s -> s.length() % 2 == 0)
                .toList();

//        P5. Turn the strings into upper case, keep only those shorter than 4 characters, of the remaining ones keep
//        only those that contain "E", and print the first result. Repeat the process, checking for a "Q" instead of an
//        "E" – without repeating the code of the first version. What is the type of the result, and what happens
//        when nothing matches?
//        Expected: Optional[BYE], and Optional.empty for "Q".

        Function<String, Optional<String>> myFunction = x ->
        words.stream()
                .filter(s -> s.length() < 4)
                .map(String::toUpperCase)
                .filter(s -> s.contains(x))
                .findFirst();

        System.out.println(myFunction.apply("E"));
        System.out.println(myFunction.apply("Q"));

//        P6. Produce a single String that concatenates the upper-case versions of all the words. Use a single
//        reduce, without map.

//        "" + "hi".toUpperCase() = "HI";
//        "HI" + "hello".toUpperCase();
//        List.of("hi", "hello", "bye", "goodbye", "java", "stream",
//                "lambda", "map", "filter", "reduce", "eye", "queue", "collect", "Hello");

        String p6 = words.stream().reduce("", (acc, w) -> acc + w.toUpperCase());
        System.out.println(p6);

//        P7. Produce the same String with a map that turns the words into upper case, followed by a reduce that
//        concatenates them. Write the reduction with a method reference.

        String p7 = words.stream().map(String::toUpperCase).reduce("", (acc, w) -> acc + w);
        System.out.println(p7);

//        P8. Produce the words concatenated with commas in between: "hi,hello,bye,…" – no comma at the
//        beginning and none at the end. Major hint: there are two versions of reduce. Then solve it again with a
//        collector.


//        "hi" + "," + "hello"
//        "hi,hello" + "," + "bye"
//        List.of("hi", "hello", "bye", "goodbye", "java", "stream",
//                "lambda", "map", "filter", "reduce", "eye", "queue", "collect", "Hello");

        String p8 = words.stream().reduce((a, b) -> a + "," + b).orElse("");
        System.out.println(p8);

        String collector8 = words.stream().collect(Collectors.joining(","));
        System.out.println(collector8);

//        P9. Find the total number of characters (the sum of the lengths) of the words.
//        Expected: 68

        int total = words.stream()
                .map(s -> s.length())
                .reduce(0, (a,b) -> a + b);

        int total2 = words.stream()
                .mapToInt(String::length)
                .sum();

        System.out.println(total);
        System.out.println(total2);

//        P10. Find the number of words that contain an "h". Then count them ignoring the case. Why are the two
//        results different?
//        Expected: 2, and 3 ignoring the case.

        long result1 = words.stream()
                .filter(s -> s.contains("h"))
                .count();

        long result2 = words.stream()
                .filter(s -> s.toLowerCase().contains("h"))
                .count();

        System.out.println(result1 + "," + result2);


//        P11. Group the words by their length: build a Map<Integer, List<String>>, with the lengths in
//        increasing order.
//        Expected: {2=[hi], 3=[bye, map, eye], 4=[java], 5=[hello, queue, Hello], 6=[stream,
//                lambda, filter, reduce], 7=[goodbye, collect]}

        Map<Integer, List<String>> p11 = words.stream()
                .collect(Collectors.groupingBy(
                        String::length,
                        HashMap::new,
                        Collectors.toList())
                );

        System.out.println(p11);

//        P12. Split the words into those of even and those of odd length and count each part, in one pass over the
//        stream (partitioningBy with a downstream collector).
//                Expected: {false=8, true=6}

        Map<Boolean, Long> p12 = words.stream()
                .collect(Collectors.partitioningBy(s -> s.length() % 2 == 0, Collectors.counting()));
        System.out.println(p12);

//        P13. Produce the list of distinct words, ignoring the case, sorted by decreasing length and, for equal
//        lengths, alphabetically. Build the comparator with
//        Comparator.comparing(…).reversed().thenComparing(…).
//                Expected: [collect, goodbye, filter, lambda, reduce, stream, hello, queue, java, bye,
//                eye, map, hi]

        List<String> p13 = words.stream()
                .map(String::toLowerCase)
                .distinct()
                .sorted(
                        Comparator.comparingInt(String::length)
                                .reversed()
                                .thenComparing(Comparator.naturalOrder())
                )
                .toList();
        System.out.println(p13);

//        P14. Count how many times each letter occurs in all the words, ignoring the case: a Map<Character,
//                Long> sorted by letter. Hint: String::chars gives an IntStream; you need flatMap.
//                Expected: {a=6, b=3, c=3, d=3, e=13, f=1, …, y=3} – the most frequent letter is e.

        HashMap<Character, Long> p14 = words.stream()
                .flatMap(s -> s.toLowerCase().chars().mapToObj(c -> (char) c))
                .collect(Collectors.groupingBy(
                        Function.identity(),
                        HashMap::new,
                        Collectors.counting()
                ));

        System.out.println(p14);

//        P15. Find all the words of maximal length. Solve it twice: with two streams (first the maximal length, then
//                the words), and with a single stream, using the map of P11.
//        Expected: [goodbye, collect]

        int maxLength = words.stream()
                .mapToInt(String::length)
                .max()
                .orElse(0);

        Map<Integer, List<String>> p15 = words.stream()
                .collect(Collectors.groupingBy(
                        String::length,
                        TreeMap::new,
                        Collectors.toList()
                ));

        List<String> longest = p15.get(((TreeMap<Integer, List<String>>) p15).lastKey());
        System.out.println(longest);

//        P16. Generate the first 15 Fibonacci numbers with Stream.iterate, without any variable outside the
//        stream. Then find the first Fibonacci number greater than 1000. Hint: iterate over pairs of consecutive
//        numbers.
//                Expected: [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377] and 1597.

//        [0,1]
//        [1,1]
//        [1,2]
//        [2,3]
//        [3,5]
//        ...
        List<Integer> fibonacci = Stream.iterate(
                new int[]{0,1}, p -> new int[]{p[1], p[0] + p[1]}
        )
                .limit(15)
                .map(p -> p[0])
                .toList();

        int p16 = Stream.iterate(
                new int[]{0,1}, p -> new int[]{p[1], p[0] + p[1]}
        )
                .map(p -> p[0])
                .filter(x -> x > 1000)
                .findFirst()
                .orElse(0);

        System.out.println(fibonacci);
        System.out.println(p16);

//        P17. Compute the average grade of each group of students, with the groups in increasing order.
//                Expected: {921=6.67, 922=6.83, 923=6.75} (rounded).

        HashMap<Integer, Double> p17 = students.stream()
                .collect(Collectors.groupingBy(
                        Student::group,
                        HashMap::new,
                        Collectors.averagingDouble(Student::grade))
                );

        System.out.println(p17);

//        P18. a) Find the best student of each group – once with groupingBy and maxBy, once with toMap and
//        BinaryOperator.maxBy. Why does the first version give Optional values?
//
        Map<Integer, Optional<Student>> p18a = students.stream()
                .collect(Collectors.groupingBy(
                        Student::group,
                        TreeMap::new,
                        Collectors.maxBy(
                                Comparator.comparingDouble(Student::grade)
                        )
                ));

        Map<Integer, Student> p18a2 = students.stream()
                .collect(Collectors.toMap(
                        Student::group,
                        Function.identity(),
                        BinaryOperator.maxBy(
                                Comparator.comparingDouble(Student::grade)
                        ),
                        TreeMap::new
                ));
//
//        b) Produce the names of the
//        students who passed (grade ≥ 5) in alphabetical order, as one string separated by ", ".
//
        String p18b = students.stream()
                .filter(s -> s.grade() >= 5)
                .map(Student::name)
                .sorted()
                .collect(Collectors.joining(", "));
//
//        c) Compute the
//        number of students, the minimum, the maximum and the average grade with a single terminal operation.
//

        DoubleSummaryStatistics p18c = students.stream()
                .collect(Collectors.summarizingDouble(Student::grade));

        System.out.println(p18c.getCount());
        System.out.println(p18c.getMin());
        System.out.println(p18c.getAverage());
        System.out.println(p18c.getMax());

//
//        Expected: a) 921 → Ana, 922 → Elena, 923 → Dan; b) Ana, Carmen, Dan, Elena, Florin, Horia; c)
//        count=8, min=3.5, average=6.75, max=10.0.

//        P19. Given a list of transformations, compose them into one function with reduce and apply it to every
//        word:
//        List<Function<String, String>> steps = List.of(
//                String::trim, String::toUpperCase, s -> s + "!", s -> s.replace("E", "3"));
//        What is the identity element of the reduction? Does the order of composition matter – what changes with
//        Function::compose instead of Function::andThen?
//                Expected: [HI!, H3LLO!, BY3!, GOODBY3!, …, COLL3CT!, H3LLO!]


        List<Function<String, String>> steps = List.of(
                String::trim,
                String::toUpperCase,
                s -> s + "!",
                s -> s.replace("E", "3")
        );

        Function<String, String> pipeline = steps.stream()
                .reduce(
                        Function.identity(),
                        Function::andThen
                );

        List<String> p19 = words.stream()
                .map(pipeline)
                .toList();


//        P20. From text, find the 3 most frequent words with their number of occurrences: ignore the case and the
//        punctuation, sort by decreasing frequency and, for equal frequencies, alphabetically. Write it as one stream
//        pipeline (you may start a second stream from the entries of a map).
//                Expected: [is=4, stream=3, the=3]


        List<Map.Entry<String, Long>> p20 =
                Arrays.stream(
                                text.toLowerCase()
                                        .split("[^a-z]+")
                        )
                        .filter(s -> !s.isEmpty())
                        .collect(Collectors.groupingBy(
                                Function.identity(),
                                Collectors.counting()
                        ))
                        .entrySet()
                        .stream()
                        .sorted(
                                Map.Entry.<String, Long>comparingByValue()
                                        .reversed()
                                        .thenComparing(Map.Entry.comparingByKey())
                        )
                        .limit(3)
                        .toList();

    }
}
